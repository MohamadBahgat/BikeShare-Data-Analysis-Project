
"""
Created on Fri Dec 17 03:36:05 2021

@author: Mohamed Bahgat
"""

#Function [1] makes a function called get_x that asks the user to enter an integer within the range 5:10.
#this function should return an integer within 5:10.

def get_x():
    #write your code here.
    #hint use input method to ask the user and make sure that user
    #enter a number within the range(5,10).

    while True:
        try:
            n = int(input("just choose how many numbers you want " +
                          "to enter from next (5 to 10) \n"))
            if n == 0:
                print("Could you please, choose any other number than ZERO!")
                continue
            break
        except:
            print("Please Enter A Valid Number!")            
        finally:
            print("_" * 40 + "\n")
    return n

#Function [2] make a function called lst_x take that integer and return a list with random numbers.
#for example lst_x(5) should return something like that = [52,3,4,9100,47]
#choose any random numbers.

def lst_x(x):
    lst_nums = [0] * x
    #write your code here.
    #hint use for loop
    for i in range(x):
        while True:
            try:
                print("({}) Enter any random number.".format(i+1))
                num = int(input())
                break
            except:
                print("Please Enter A Valid Number!")
        lst_nums[i] = num
        #print(lst_nums)
        print("_" * 40 + "\n")
    return lst_nums
    



#Function [3] get_max takes a list and returns the max number.
#Attention does not allow to use max() method with the list.

def get_max(lst):
    max_num = lst[0]
    #hint use for loop
    for current in lst:
        if max_num <= current:
           max_num = current
    
    print("The max number is ", max_num)
    print("_" * 40 + "\n")


#Function [4] get_min takes a list and returns the min number.
#Attention does not allow to use min() method with the list.

def get_min(lst):
    min_num = lst[0]
    #use for loop or while loop or something else but don't use min() method
    for current in lst:
        if min_num >= current:
           min_num = current
    print("The min number is ", min_num)
    print("_" * 40 + "\n")

# Function[5] return the total/sum of the list.
def get_total(lst):
    total = 0
    #write your code here
    for current in lst:
        total += current
    print("The sum of all numbers are ", total)
    print("_" * 40 + "\n")

#Function[6]
def get_count(lst):
    #write your code here
    count = lst.index(lst[-1])+1
        
    print(f"we have {count} numbers in the list")
    print("_" * 40 + "\n")


#the last function is the main function that holds all functions together.

def main():
    while True:
        x = get_x()
        my_lst = lst_x(x)
        get_max(my_lst)
        get_min(my_lst)
        get_total(my_lst)
        get_count(my_lst)


        restart = input('\nDo you want to play again? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break


if __name__ == "__main__":
	main()