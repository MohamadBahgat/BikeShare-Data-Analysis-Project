# -*- coding: utf-8 -*-
"""
Created on Thu Dec 16 05:35:13 2021

@author: Mohamed Bahgat
"""

# Write your code here
dict_of_flowers = {}
def seperate(name):
    first_letter = name[0]
    first_letter = first_letter.upper()
    if first_letter.isalpha():
        with open('C:\\Users\\Mohamad Bahgat\\Desktop\\flowers.txt') as flowers_file:
           for f in flowers_file:
               key, value = f.split(":")
               value = value.strip()
               dict_of_flowers[key] = value
        #print(dict_of_flowers)       
        print(dict_of_flowers.get(first_letter))
    else:
        print('You have not entered a correct name format')
       
# HINT: create a dictionary from flowers.txt

# HINT: create a function to ask for user's first and last name
name = input("Enter Your Name, plz! \n")
seperate(name)
# print the desired output
